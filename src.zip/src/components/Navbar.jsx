import React from 'react';
import './NavBar.css';

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="navbar-container">
        <img src="https://source.unsplash.com/100x40/?startup,logo" alt="ECell Logo" className="logo" />
        <nav className="navbar-links">
          <a href="#">Home</a>
          <a href="#about">About</a>
          <a href="#vision">Our Vision</a>
          <a href="#blogs">Blogs</a>
          <a href="#membership">Membership</a>
        </nav>
        <a href="#" className="get-started">Get Started 🚀</a>
      </div>
    </header>
  );
};

export default Navbar;
